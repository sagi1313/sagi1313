# AsStrongAsFuck
Modified AsStrongAsFuck (original: https://github.com/Charterino/AsStrongAsFuck)

A nice .NET obfuscator.

Will add anti-debug, anti-tamper etc. soon for increased protection.
