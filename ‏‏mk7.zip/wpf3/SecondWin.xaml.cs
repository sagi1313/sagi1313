﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for SecondWin.xaml
    /// </summary>
    public partial class SecondWin : Window
    {
        public string file;
        public string output;
        public string obs_type;
        public SecondWin()
        {
            InitializeComponent();
        }

        private void Path_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Btn8_Checked(object sender, RoutedEventArgs e)
        {
            int counter = 0;
            if (btn2.IsChecked == true)
            {
                counter++;
            }
            if (btn3.IsChecked == true)
            {
                counter++;
            }
            if (btn4.IsChecked == true)
            {
                counter++;
            }
            if (btn5.IsChecked == true)
            {
                counter++;
            }
            if (btn6.IsChecked == true)
            {
                counter++;
            }
            if (btn7.IsChecked == true)
            {
                counter++;
            }
            if (btn1.IsChecked == true)
            {
                counter++;
            }
            if (btn9.IsChecked == true)
            {
                counter++;
            }
            if (counter > 1)
            {
                btn8.IsChecked = false;
            }
        }

        private void Btn9_Checked(object sender, RoutedEventArgs e)
        {
            int counter = 0;
            if (btn2.IsChecked == true)
            {
                counter++;
            }
            if (btn3.IsChecked == true)
            {
                counter++;
            }
            if (btn4.IsChecked == true)
            {
                counter++;
            }
            if (btn5.IsChecked == true)
            {
                counter++;
            }
            if (btn6.IsChecked == true)
            {
                counter++;
            }
            if (btn7.IsChecked == true)
            {
                counter++;
            }
            if (btn8.IsChecked == true)
            {
                counter++;
            }
            if (btn1.IsChecked == true)
            {
                counter++;
            }
            if (counter > 1)
            {
                btn9.IsChecked = false;
            }
        }

        private void Btn7_Checked(object sender, RoutedEventArgs e)
        {
            int counter = 0;
            if (btn2.IsChecked == true)
            {
                counter++;
            }
            if (btn3.IsChecked == true)
            {
                counter++;
            }
            if (btn4.IsChecked == true)
            {
                counter++;
            }
            if (btn5.IsChecked == true)
            {
                counter++;
            }
            if (btn6.IsChecked == true)
            {
                counter++;
            }
            if (btn1.IsChecked == true)
            {
                counter++;
            }
            if (btn8.IsChecked == true)
            {
                counter++;
            }
            if (btn9.IsChecked == true)
            {
                counter++;
            }
            if (counter > 1)
            {
                btn7.IsChecked = false;
            }
        }

        private void Btn6_Checked(object sender, RoutedEventArgs e)
        {
            int counter = 0;
            if (btn2.IsChecked == true)
            {
                counter++;
            }
            if (btn3.IsChecked == true)
            {
                counter++;
            }
            if (btn4.IsChecked == true)
            {
                counter++;
            }
            if (btn5.IsChecked == true)
            {
                counter++;
            }
            if (btn1.IsChecked == true)
            {
                counter++;
            }
            if (btn7.IsChecked == true)
            {
                counter++;
            }
            if (btn8.IsChecked == true)
            {
                counter++;
            }
            if (btn9.IsChecked == true)
            {
                counter++;
            }
            if (counter > 1)
            {
                btn6.IsChecked = false;
            }
        }

        private void Btn5_Checked(object sender, RoutedEventArgs e)
        {
            int counter = 0;
            if (btn2.IsChecked == true)
            {
                counter++;
            }
            if (btn3.IsChecked == true)
            {
                counter++;
            }
            if (btn4.IsChecked == true)
            {
                counter++;
            }
            if (btn1.IsChecked == true)
            {
                counter++;
            }
            if (btn6.IsChecked == true)
            {
                counter++;
            }
            if (btn7.IsChecked == true)
            {
                counter++;
            }
            if (btn8.IsChecked == true)
            {
                counter++;
            }
            if (btn9.IsChecked == true)
            {
                counter++;
            }
            if (counter > 1)
            {
                btn5.IsChecked = false;
            }
        }

        private void Btn4_Checked(object sender, RoutedEventArgs e)
        {
            int counter = 0;
            if (btn2.IsChecked == true)
            {
                counter++;
            }
            if (btn3.IsChecked == true)
            {
                counter++;
            }
            if (btn1.IsChecked == true)
            {
                counter++;
            }
            if (btn5.IsChecked == true)
            {
                counter++;
            }
            if (btn6.IsChecked == true)
            {
                counter++;
            }
            if (btn7.IsChecked == true)
            {
                counter++;
            }
            if (btn8.IsChecked == true)
            {
                counter++;
            }
            if (btn9.IsChecked == true)
            {
                counter++;
            }
            if (counter > 1)
            {
                btn4.IsChecked = false;
            }
        }

        private void Btn3_Checked(object sender, RoutedEventArgs e)
        {
            int counter = 0;
            if (btn2.IsChecked == true)
            {
                counter++;
            }
            if (btn1.IsChecked == true)
            {
                counter++;
            }
            if (btn4.IsChecked == true)
            {
                counter++;
            }
            if (btn5.IsChecked == true)
            {
                counter++;
            }
            if (btn6.IsChecked == true)
            {
                counter++;
            }
            if (btn7.IsChecked == true)
            {
                counter++;
            }
            if (btn8.IsChecked == true)
            {
                counter++;
            }
            if (btn9.IsChecked == true)
            {
                counter++;
            }
            if (counter > 1)
            {
                btn3.IsChecked = false;
            }
        }

        private void Btn2_Checked(object sender, RoutedEventArgs e)
        {
            int counter = 0;
            if (btn1.IsChecked == true)
            {
                counter++;
            }
            if (btn3.IsChecked == true)
            {
                counter++;
            }
            if (btn4.IsChecked == true)
            {
                counter++;
            }
            if (btn5.IsChecked == true)
            {
                counter++;
            }
            if (btn6.IsChecked == true)
            {
                counter++;
            }
            if (btn7.IsChecked == true)
            {
                counter++;
            }
            if (btn8.IsChecked == true)
            {
                counter++;
            }
            if (btn9.IsChecked == true)
            {
                counter++;
            }
            if (counter > 1)
            {
                btn2.IsChecked = false;
            }
        }

        private void Btn1_Checked(object sender, RoutedEventArgs e)
        {
            int counter = 0;
            if (btn2.IsChecked == true)
            {
                counter++;
            }
            if (btn3.IsChecked == true)
            {
                counter++;
            }
            if (btn4.IsChecked == true)
            {
                counter++;
            }
            if (btn5.IsChecked == true)
            {
                counter++;
            }
            if (btn6.IsChecked == true)
            {
                counter++;
            }
            if (btn7.IsChecked == true)
            {
                counter++;
            }
            if (btn8.IsChecked == true)
            {
                counter++;
            }
            if (btn9.IsChecked == true)
            {
                counter++;
            }
            if (counter>1)
            {
                btn1.IsChecked = false;
            }



        }

        private void Btn8_UnChecked(object sender, RoutedEventArgs e)
        {

        }

        private void Btn9_UnChecked(object sender, RoutedEventArgs e)
        {

        }

        private void Btn7_UnChecked(object sender, RoutedEventArgs e)
        {

        }

        private void Btn6_UnChecked(object sender, RoutedEventArgs e)
        {

        }

        private void Btn5_UnChecked(object sender, RoutedEventArgs e)
        {

        }

        private void Btn4_UnChecked(object sender, RoutedEventArgs e)
        {

        }

        private void Btn3_UnChecked(object sender, RoutedEventArgs e)
        {

        }

        private void Btn2_UnChecked(object sender, RoutedEventArgs e)
        {

        }

        private void Btn1_UnChecked(object sender, RoutedEventArgs e)
        {
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string obs;
            if (File.Exists("test.txt"))
            {
                File.Delete("test.txt");
            }
            file = path.Text;

            StreamWriter sw = new StreamWriter("C:\\Users\\user\\Desktop\\mk_6\\txt.txt");
            //Write the out put for the obfuscator
            sw.WriteLine(file);
            sw.WriteLine(check_check());
            sw.WriteLine(file);
            //Close the file
            sw.Close();
            string strCmdText;
            strCmdText = @"/C start C:\Users\user\Desktop\mk_6\mk_5\mk_2_obfuscator\AsStrongAsFuck-Modified-master\AsStrongAsFuck-Modified-master\AsStrongAsFuck\bin\Debug\AsStrongAsFuck.exe";
            System.Diagnostics.Process.Start("CMD.exe", strCmdText);


            StreamWriter sw2 = new StreamWriter("C:\\Users\\user\\Desktop\\mk_6\\txt.txt");
            //Write the out put for the obfuscator
            sw2.WriteLine(file);
            sw2.WriteLine(check_check());
            sw2.WriteLine(file);
            //Close the file
            sw.Close();
            strCmdText = @"/C start C:\Users\user\Desktop\mk_6\mk_5\mk_2_obfuscator\AsStrongAsFuck-Modified-master\AsStrongAsFuck-Modified-master\AsStrongAsFuck\bin\Debug\AsStrongAsFuck.exe";
            System.Diagnostics.Process.Start("CMD.exe", strCmdText);

        }
        public string check_check()
        {
            if (btn1.IsChecked == true)
            {
                obs_type = "1";
                btn1.IsChecked = false;
            }
            else if (btn2.IsChecked == true)
            {
                obs_type = "2";
                btn2.IsChecked = false;
            }
            else if (btn3.IsChecked == true)
            {
                obs_type = "3";
                btn3.IsChecked = false;
            }
            else if (btn4.IsChecked == true)
            {
                obs_type = "4";
                btn4.IsChecked = false;
            }
            else if (btn5.IsChecked == true)
            {
                obs_type = "5";
                btn5.IsChecked = false;
            }
            else if (btn6.IsChecked == true)
            {
                obs_type = "6";
                btn6.IsChecked = false;
            }
            else if (btn7.IsChecked == true)
            {
                obs_type = "7";
                btn7.IsChecked = false;
            }
            else if (btn8.IsChecked == true)
            {
                obs_type = "8";
                btn8.IsChecked = false;
            }
            else
            {
                obs_type = "9";
                btn9.IsChecked = false;
            }

            return (obs_type);
        }
    }
}
