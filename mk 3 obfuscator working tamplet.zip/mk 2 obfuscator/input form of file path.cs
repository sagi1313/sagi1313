﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public static string SetValueForText1 = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (File.Exists("test.exe"))
            {
                File.Delete("test.exe");
            }
            SetValueForText1 = textBox1.Text;
                //Pass the filepath and filename to the StreamWriter Constructor
                StreamWriter sw = new StreamWriter("C:\\Users\\user\\Desktop\\mk 2 obfuscator\\Test1.txt");
                //Write a line of text
                sw.WriteLine(SetValueForText1);
                //Write a second line of text
                //Close the file
                sw.Close();

        }
    }
}
