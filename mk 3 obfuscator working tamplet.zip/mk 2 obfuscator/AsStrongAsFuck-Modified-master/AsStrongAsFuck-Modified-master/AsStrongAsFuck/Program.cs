﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AsStrongAsFuck
{
    class Program
    {
        public static Worker Worker { get; set; }
        public static void Main(string[] args)
        {
            Console.WriteLine("Modified AsStrongAsFuck by moneydev");
            string path = read_file();
            Worker = new Worker(path);
            Console.WriteLine("Choose options to obfuscate: ");
            Console.WriteLine("I use 589127 preset.");
            for (int i = 0; i < Worker.Obfuscations.Count; i++)
            {
                Console.WriteLine(i + 1 + ") " + Worker.Obfuscations[i]);
            }
            string opts = Console.ReadLine();
            Worker.ExecuteObfuscations(opts);
            Worker.Save();
            Console.ReadLine();
        }
        public static string read_file()
        {
            string line;
                //Pass the file path and file name to the StreamReader constructor
                StreamReader sr = new StreamReader("C:\\Users\\user\\Desktop\\mk 2 obfuscator\\Test.txt");
                //Read the first line of text
                line = sr.ReadLine();
                //close the file
                sr.Close();
                return (line);

        }
    }
}
